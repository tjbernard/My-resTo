<?php

ob_start();
include 'db.php';
$username = '';
$userpwd = '';
if (isset($_REQUEST['username'])):
    if (!empty($_REQUEST['username'])):
        $username = htmlspecialchars($_GET['username']);
    else:
        header("Location: index.php?login=failed");
    //die();
    endif;
else:
    header("Location: index.php?login=failed");
// die();
endif;

if (isset($_REQUEST['userpwd'])):
    if (!empty($_REQUEST['userpwd'])):
        $userpwd = htmlspecialchars($_GET['userpwd']);

    else:
        header("Location: index.php?login=failed");
    // die();
    endif;
else:
    header("Location: index.php?login=failed");
//die();
endif;


$db_uname = '';
$db_pwd = '';
$db_role = '';


$result = mysqli_query($conn, "SELECT * FROM usermaster where username='$username' and password='$userpwd'");
$row = mysqli_fetch_row($result);

$db_uname = $row[1];
$db_pwd = $row[2];
$db_role = $row[3];

if ($db_uname == $username):
    if ($db_pwd == $userpwd):
        session_start();
        $_SESSION['usr'] = $db_uname;

        if ($db_role == "admin") {
            $_SESSION['them'] = "adminthem";
            header("Location:DashBoard.php?login=success");
        } else if ($db_role == "superadmin") {
            $_SESSION['them'] = "them";
            header("Location:DashBoard.php?login=success");
        } else if ($db_role == "accountmanager") {
            $_SESSION['them'] = "accountThem";
            header("Location:DashBoard.php?login=success");
        } else if ($db_role == "kitchenmanager") {
            $_SESSION['them'] = "kitchenthem";
            header("Location: kitchenHome.php?login=success");
        } else
            header("Location: index.php?login=failed");

    else:
        header("Location: index.php?login=failed");

    endif;
else:
    header("Location: index.php?login=failed");
        
    endif;
