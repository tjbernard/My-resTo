-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 29, 2015 at 02:52 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE IF NOT EXISTS `admin_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(50) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `uname`, `pwd`) VALUES
(1, 'admin', 'admin@123');

-- --------------------------------------------------------

--
-- Table structure for table `cusine`
--

CREATE TABLE IF NOT EXISTS `cusine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cusinename` varchar(100) NOT NULL,
  `cusineimage` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `cusine`
--

INSERT INTO `cusine` (`id`, `cusinename`, `cusineimage`) VALUES
(1, 'Chinese', 'chinese.jpeg'),
(3, 'Punjabi', 'kana.jpg'),
(11, 'South Indian1', 'p.jpg'),
(15, 'Starter', 'noimage.png'),
(16, 'Newcusine', 'noimage.png'),
(17, 'Thali', 'noimage.png\r\n'),
(18, '', 'noimage.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `dish`
--

CREATE TABLE IF NOT EXISTS `dish` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cusineid` int(11) NOT NULL,
  `dishname` varchar(100) NOT NULL,
  `dishimage` varchar(100) NOT NULL,
  `dishtype` int(11) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `dish`
--

INSERT INTO `dish` (`id`, `cusineid`, `dishname`, `dishimage`, `dishtype`, `description`, `price`) VALUES
(1, 15, 'Manchurain', 'noimage.jpg', 2, 'qhijhjnknjkln', '50'),
(2, 16, 'Newdish', 'noimage.jpg', 1, 'asdshikhj', '45'),
(3, 17, 'Gujaratithali', 'noimage.jpg', 6, 'gujarati cusine', '250'),
(4, 15, 'wqaeqwe', 'edededcf', 2, 'dfsdf', '24');

-- --------------------------------------------------------

--
-- Table structure for table `dish_type`
--

CREATE TABLE IF NOT EXISTS `dish_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typename` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `dish_type`
--

INSERT INTO `dish_type` (`id`, `typename`) VALUES
(1, 'sweet'),
(2, 'Spicy'),
(6, 'Stir fried'),
(7, '');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `memberid` varchar(100) NOT NULL,
  `membername` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `feedback` varchar(300) NOT NULL,
  `feedback_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `memberid`, `membername`, `phone`, `feedback`, `feedback_time`) VALUES
(1, '1', 'utpal', '9909777668', 'Its awsome', '2014-12-16 19:01:48');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `memberid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `address` varchar(300) NOT NULL,
  `gcmid` varchar(200) NOT NULL,
  `logintype` varchar(50) NOT NULL,
  `member_since` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`memberid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`memberid`, `firstname`, `lastname`, `email`, `phone`, `address`, `gcmid`, `logintype`, `member_since`) VALUES
(1, 'Utpal', 'ruparel', 'utpalruparel@gmail.com', '9909777668', 'Bhakti Dharam Township', '4654765414165314631', 'email', '2014-12-16 19:05:18');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE IF NOT EXISTS `orderdetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dishid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `status` varchar(11) NOT NULL,
  `orderid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`id`, `dishid`, `quantity`, `price`, `status`, `orderid`) VALUES
(1, 57, 1, 150, '1', 2),
(2, 58, 1, 120, '1', 3),
(3, 57, 12, 1800, '0', 4),
(4, 8, 2, 400, '0', 4),
(5, 58, 3, 360, '0', 4),
(6, 58, 2, 240, '0', 0),
(7, 58, 1, 120, '0', 5),
(8, 8, 6, 1200, '0', 0),
(9, 8, 2, 400, '0', 0),
(10, 57, 3, 450, '0', 6),
(11, 8, 4, 800, '0', 6),
(12, 57, 4, 600, '1', 6),
(13, 57, 4, 600, '0', 0),
(14, 31, 2, 400, '0', 0),
(15, 8, 5, 1000, '0', 0),
(16, 8, 4, 800, '1', 7),
(17, 57, 7, 1050, '0', 7),
(18, 8, 5, 1000, '0', 7),
(19, 8, 5, 1000, '0', 8),
(20, 58, 5, 600, '0', 8),
(21, 8, 5, 1000, '0', 11),
(22, 58, 5, 600, '0', 11),
(23, 58, 3, 360, '2', 12),
(24, 57, 2, 300, '1', 13),
(25, 8, 5, 1000, '0', 13),
(26, 57, 6, 900, '0', 15),
(27, 58, 4, 480, '0', 16),
(28, 58, 1, 120, '0', 21),
(29, 8, 3, 600, '0', 22),
(30, 58, 5, 600, '0', 0),
(31, 58, 5, 0, '0', 23);

-- --------------------------------------------------------

--
-- Table structure for table `ordertable`
--

CREATE TABLE IF NOT EXISTS `ordertable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tableid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `startdatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `enddatetime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `amount` int(10) NOT NULL,
  `customername` varchar(15) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `grandtotal` int(11) NOT NULL,
  `status` varchar(15) NOT NULL,
  `paymentstatus` varchar(15) NOT NULL,
  `paymentmode` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `ordertable`
--

INSERT INTO `ordertable` (`id`, `tableid`, `userid`, `startdatetime`, `enddatetime`, `amount`, `customername`, `phone`, `grandtotal`, `status`, `paymentstatus`, `paymentmode`) VALUES
(1, 1, 1, '2015-09-29 10:46:02', '0000-00-00 00:00:00', 0, '', '', 0, '2', 'paid', '2'),
(2, 3, 1, '2015-09-29 09:45:47', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(3, 2, 1, '2015-09-29 12:05:46', '2015-09-29 08:35:46', 120, '', '', 0, '1', 'unpaid', ''),
(4, 4, 1, '2015-09-29 10:15:01', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(5, 5, 1, '2015-09-29 10:19:20', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(6, 7, 1, '2015-09-29 10:48:18', '0000-00-00 00:00:00', 0, '', '', 0, '2', 'paid', '2'),
(7, 1, 1, '2015-09-29 10:44:00', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(8, 1, 1, '2015-09-29 10:46:39', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(9, 6, 1, '2015-09-29 10:47:09', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(10, 1, 1, '2015-09-29 10:47:30', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(11, 6, 1, '2015-09-29 10:47:49', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(12, 7, 1, '2015-09-29 10:51:57', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(13, 9, 1, '2015-09-29 10:54:27', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(14, 8, 1, '2015-09-29 11:07:54', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(15, 10, 1, '2015-09-29 11:10:12', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(16, 11, 1, '2015-09-29 11:12:15', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(17, 12, 1, '2015-09-29 11:22:09', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(18, 12, 1, '2015-09-29 11:22:51', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(19, 13, 1, '2015-09-29 11:23:16', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(20, 13, 1, '2015-09-29 12:15:47', '2015-09-29 08:45:47', 0, '', '', 0, '1', 'unpaid', ''),
(21, 14, 1, '2015-09-29 11:30:42', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(22, 15, 1, '2015-09-29 11:31:28', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', ''),
(23, 14, 1, '2015-09-29 12:46:10', '0000-00-00 00:00:00', 0, '', '', 0, '1', 'unpaid', '');

-- --------------------------------------------------------

--
-- Table structure for table `paymentmode`
--

CREATE TABLE IF NOT EXISTS `paymentmode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `paymentmode`
--

INSERT INTO `paymentmode` (`id`, `type`) VALUES
(2, 'Cash'),
(4, 'Card');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `currency` varchar(50) NOT NULL,
  `tax` int(5) NOT NULL,
  `vattax` int(5) NOT NULL,
  `additionaltax` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `address`, `phone`, `currency`, `tax`, `vattax`, `additionaltax`) VALUES
(1, 'Hotel Taj', 'Mumbai', '7899632563', 'RS', 2, 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `tablemaster`
--

CREATE TABLE IF NOT EXISTS `tablemaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tablename` varchar(100) NOT NULL,
  `tablestatus` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `tablemaster`
--

INSERT INTO `tablemaster` (`id`, `tablename`, `tablestatus`) VALUES
(1, 'order1', '1'),
(2, 'or2', '1'),
(3, 'or3', '1'),
(4, 'newt', '1'),
(5, '20', '1'),
(6, 'q1', '1'),
(7, 'q2', '1'),
(8, 'm1', '1'),
(9, 'm2', '1'),
(10, 'kkkkk', '1'),
(11, 'kb', '1'),
(12, 'vb', '1'),
(13, 'j', '1'),
(14, 'and', '1'),
(15, 'bk', '1');

-- --------------------------------------------------------

--
-- Table structure for table `usermaster`
--

CREATE TABLE IF NOT EXISTS `usermaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `usermaster`
--

INSERT INTO `usermaster` (`id`, `username`, `password`, `role`) VALUES
(1, 'ramu', '123456', 'User(Waiter)'),
(7, 'raj', 'raj123', 'Account Manager'),
(10, 'Kiran', '12345', 'Admin'),
(11, 'admin', 'admin@123', 'Super Admin'),
(12, 'minesh', '12345', 'Kitchen Manager');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
